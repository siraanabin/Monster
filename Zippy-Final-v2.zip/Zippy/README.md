# Zippy — Android Video Downloader
Kotlin + Compose + yt-dlp + FFmpegKitNext + Media3

## Real engine (not prototype)
1. Extraction: youtubedl-android fork (Chaquopy CPython + yt-dlp) - Seal app er moto approach
2. Download: yt-dlp --newline progress parsing, kokhono fake progress na
3. Merge: FFmpegKitNext -c copy, Convert: MP3/M4A/AAC
4. Player: Media3 ExoPlayer, gestures, background audio via MediaSessionService
5. Queue: WorkManager + ForegroundService (dataSync), Room history, MediaStore Downloads/Zippy

Build: Android Studio Ladybug+, JDK 17, AGP 8.6.1, minSdk 26, targetSdk 35
Legal: Sudhu public / rights-allowed content. DRM / private / login-walled support kora hobe na.
