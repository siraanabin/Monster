# Zippy - GitHub Auto Build Guide (Bangla)

## Tui ki pabi?
Push dilei GitHub nije APK baniye dibe. Tor PC te Android Studio lagbe na APK er jonno.

## Step 1: GitHub e Repo Bana
1. github.com e giye New Repository > Name: `Zippy` > Public > Create
2. Ei ZIP ta unzip kore sob file (`.github` folder soho) oi repo te upload kor / git push kor

```bash
git init
git add .
git commit -m "Zippy v1 - auto build"
git branch -M main
git remote add origin https://github.com/TOR-USERNAME/Zippy.git
git push -u origin main
```

**Important:** `.github` folder hidden - Windows e `Show hidden files` on kore check korbi, na hole workflow jabe na.

## Step 2: Auto Build Dekh
- Repo > **Actions** tab > `Zippy - Auto Build APK` running dekhbi
- 3-5 min por green tick asbe
- **Actions > Artifacts** > `Zippy-debug-apk` download kor > phone e install kor

## Step 3: Release APK (Tag dile)
```bash
git tag v1.0.0
git push origin v1.0.0
```
Tag push dilei **Releases** e `app-release-unsigned.apk` auto upload hobe. Sobai oi link theke download korte parbe.

## Signed Release (Play Store / F-Droid er jonno, optional)
Debug APK install hoy, kintu update er jonno same signature lagbe. Signed korte chaile:
1. Android Studio > Build > Generate Signed App Bundle > keystore bana
2. GitHub Repo > Settings > Secrets > Actions e add kor:
   - `ANDROID_KEYSTORE_BASE64` - keystore er base64
   - `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
3. Amake bol, ami workflow e signing step add kore dibo.

## Jodi Build Fail Hoy
- Actions > failed run > log e error dekh
- Sobcheye common: `gradle-wrapper.jar` missing - kintu ei workflow e `gradle/actions/setup-gradle` use kora, tai eta fail korbe na
- `minSdk 26` er niche phone e install hobe na

## Local Build
Android Studio te open kore Run dilei hobe.
