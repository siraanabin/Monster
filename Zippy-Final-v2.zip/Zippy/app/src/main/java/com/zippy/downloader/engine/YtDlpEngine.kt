package com.zippy.downloader.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.io.File

data class VideoFormat(
    val formatId: String, val ext: String, val resolution: String, val height: Int,
    val fps: Double?, val vcodec: String?, val acodec: String?,
    val filesize: Long?, val filesizeApprox: Long?,
    val isAudioOnly: Boolean, val isVideoOnly: Boolean
)
data class VideoInfo(
    val id: String, val title: String, val uploader: String, val thumbnail: String?,
    val duration: Long, val webpageUrl: String, val formats: List<VideoFormat>,
    val isLive: Boolean
)

interface YtDlpEngine {
    suspend fun getInfo(url: String): Result<VideoInfo>
    suspend fun download(url: String, formatId: String, outDir: File, onProgress: (Float, Long, Long) -> Unit): Result<File>
}

// Production note: Seal app er moto youtubedl-android (Chaquopy + yt-dlp) use koro.
// Ekhane yt-dlp --dump-json wrapper deya holo jate binary update kora jay + test kora jay.
// Fake format kokhono return kora hobe na - yt-dlp ja dey, sudhu setai dekhabe.
class YtDlpEngineImpl : YtDlpEngine {
    override suspend fun getInfo(url: String): Result<VideoInfo> = withContext(Dispatchers.IO) {
        try {
            val proc = ProcessBuilder("yt-dlp", "--dump-json", "--no-playlist", "--no-warnings", url)
                .redirectErrorStream(true).start()
            val out = proc.inputStream.bufferedReader().readText()
            proc.waitFor()
            if (out.isBlank()) return@withContext Result.failure(Exception("No info found. Link private / expired / unsupported hote pare."))
            val json = Json.parseToJsonElement(out).jsonObject
            val formats = json["formats"]?.jsonArray?.mapNotNull { f ->
                val o = f.jsonObject
                val h = o["height"]?.jsonPrimitive?.intOrNull ?: 0
                VideoFormat(
                    formatId = o["format_id"]?.jsonPrimitive?.content ?: return@mapNotNull null,
                    ext = o["ext"]?.jsonPrimitive?.content ?: "mp4",
                    resolution = o["resolution"]?.jsonPrimitive?.content ?: if (h > 0) "${h}p" else "audio",
                    height = h,
                    fps = o["fps"]?.jsonPrimitive?.doubleOrNull,
                    vcodec = o["vcodec"]?.jsonPrimitive?.contentOrNull,
                    acodec = o["acodec"]?.jsonPrimitive?.contentOrNull,
                    filesize = o["filesize"]?.jsonPrimitive?.longOrNull,
                    filesizeApprox = o["filesize_approx"]?.jsonPrimitive?.longOrNull,
                    isAudioOnly = (o["vcodec"]?.jsonPrimitive?.contentOrNull == "none"),
                    isVideoOnly = (o["acodec"]?.jsonPrimitive?.contentOrNull == "none")
                )
            } ?: emptyList()
            Result.success(
                VideoInfo(
                    id = json["id"]?.jsonPrimitive?.content ?: "",
                    title = json["title"]?.jsonPrimitive?.content ?: "Untitled",
                    uploader = json["uploader"]?.jsonPrimitive?.content ?: json["channel"]?.jsonPrimitive?.content ?: "",
                    thumbnail = json["thumbnail"]?.jsonPrimitive?.contentOrNull,
                    duration = json["duration"]?.jsonPrimitive?.longOrNull ?: 0,
                    webpageUrl = url,
                    formats = formats.distinctBy { it.formatId },
                    isLive = json["is_live"]?.jsonPrimitive?.booleanOrNull ?: false
                )
            )
        } catch (e: Exception) { Result.failure(e) }
    }

    override suspend fun download(url: String, formatId: String, outDir: File, onProgress: (Float, Long, Long) -> Unit): Result<File> = withContext(Dispatchers.IO) {
        try {
            outDir.mkdirs()
            // Real progress: yt-dlp --newline parsing. Fake progress NAI.
            val template = outDir.absolutePath + "/%(title)s.%(ext)s"
            val proc = ProcessBuilder("yt-dlp", "-f", formatId, "--newline", "--progress-template", "%(progress._percent_str)s|%(progress.downloaded_bytes)s|%(progress.total_bytes)s", "-o", template, url)
                .redirectErrorStream(true).start()
            proc.inputStream.bufferedReader().forEachLine { line ->
                val parts = line.split("|")
                if (parts.size == 3) {
                    val pct = parts[0].trim().removeSuffix("%").toFloatOrNull()?.div(100f) ?: 0f
                    onProgress(pct, parts[1].toLongOrNull() ?: 0, parts[2].toLongOrNull() ?: 0)
                }
            }
            proc.waitFor()
            val file = outDir.listFiles()?.maxByOrNull { it.lastModified() }
            if (file != null) Result.success(file) else Result.failure(Exception("Download failed"))
        } catch (e: Exception) { Result.failure(e) }
    }
}
