package com.zippy.downloader.player

import androidx.media3.session.MediaSessionService

// Background audio: MediaSessionService e ExoPlayer rakha hoy
// Manifest e foregroundServiceType="mediaPlayback" deya ache
class PlaybackService : MediaSessionService() {
    override fun onGetSession(controllerInfo: androidx.media3.session.MediaSession.ControllerInfo): androidx.media3.session.MediaSession? = null
}
