package com.zippy.downloader.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

// Media3 Player: Left swipe = brightness, Right swipe = volume, Horizontal = seek
// Background audio: PlaybackService (MediaSessionService) e player rakha hoy - ekhane UI sudhu PlayerView
@Composable
fun PlayerScreen(videoPath: String) {
    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = ExoPlayer.Builder(ctx).build().apply {
                        setMediaItem(MediaItem.fromUri(videoPath)); prepare(); play()
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}
