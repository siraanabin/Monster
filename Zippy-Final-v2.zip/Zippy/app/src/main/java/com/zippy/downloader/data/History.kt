package com.zippy.downloader.data

import androidx.room.*

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val url: String, val title: String, val filePath: String,
    val ext: String, val size: Long, val createdAt: Long, val duration: Long
)

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    suspend fun all(): List<DownloadEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(e: DownloadEntity)
    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: String)
    @Query("DELETE FROM downloads")
    suspend fun clearAll()
}

@Database(entities = [DownloadEntity::class], version = 1, exportSchema = false)
abstract class ZippyDb : RoomDatabase() { abstract fun dao(): DownloadDao }
