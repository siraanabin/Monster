package com.zippy.downloader.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun MainScreen(
    initialUrl: String = "",
    onDownload: (String) -> Unit = {},
    onOpenManager: () -> Unit = {},
    onOpenLibrary: () -> Unit = {}
) {
    var url by remember { mutableStateOf(initialUrl) }
    var clipboardText by remember { mutableStateOf<String?>(null) }
    var showPasteSuggestion by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row { Icon(Icons.Default.Bolt, null); Text("Zippy", style = MaterialTheme.typography.headlineLarge) }
        Text("Paste any video link. No login. Local processing.", style = MaterialTheme.typography.bodyMedium)
        OutlinedTextField(
            value = url, onValueChange = { url = it },
            label = { Text("Paste video URL") },
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = { IconButton(onClick = { clipboardText?.let { url = it } }) { Icon(Icons.Default.ContentPaste, "Paste") } }
        )
        if (showPasteSuggestion && clipboardText != null) {
            AssistChip(onClick = { url = clipboardText!!; showPasteSuggestion = false }, label = { Text("Paste from clipboard? ${clipboardText!!.take(40)}") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { onDownload(url) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("Download") }
            OutlinedButton(onClick = { clipboardText?.let { url = it } }) { Text("Paste Link") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onOpenManager) { Icon(Icons.Default.List, null); Text("Download Manager") }
            OutlinedButton(onClick = onOpenLibrary) { Icon(Icons.Default.Folder, null); Text("Library") }
        }
        Text("Recent Downloads", style = MaterialTheme.typography.titleMedium)
        Text("Supported: yt-dlp supported sites (1000+). DRM / private / login-walled content supported na.", style = MaterialTheme.typography.bodySmall)
    }
}
