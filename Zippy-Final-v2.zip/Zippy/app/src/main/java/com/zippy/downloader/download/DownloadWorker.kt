package com.zippy.downloader.download

import android.content.Context
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.zippy.downloader.engine.YtDlpEngineImpl
import java.io.File

class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val url = inputData.getString("url") ?: return Result.failure()
        val formatId = inputData.getString("formatId") ?: "best"
        val title = inputData.getString("title") ?: "video"
        setForeground(createForegroundInfo(title))
        val outDir = File(applicationContext.getExternalFilesDir(null), "Zippy")
        val engine = YtDlpEngineImpl()
        return try {
            val res = engine.download(url, formatId, outDir) { pct, dl, total ->
                setProgressAsync(workDataOf("progress" to pct, "downloaded" to dl, "total" to total))
            }
            if (res.isSuccess) Result.success() else Result.retry()
        } catch (e: Exception) { Result.retry() }
    }
    private fun createForegroundInfo(title: String): ForegroundInfo {
        val notif = NotificationCompat.Builder(applicationContext, "zippy_download")
            .setContentTitle("Downloading $title")
            .setContentText("Zippy is downloading...")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true).build()
        return ForegroundInfo(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }
}
class DownloadForegroundService : android.app.Service() {
    override fun onBind(i: android.content.Intent?) = null
}
