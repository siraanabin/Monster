package com.zippy.downloader

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.zippy.downloader.ui.MainScreen
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = if (intent?.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT) else null
        val sharedUrl = shared?.let { Regex("https?://[^\\s]+").find(it)?.value } ?: shared
        setContent {
            MaterialTheme {
                MainScreen(
                    initialUrl = sharedUrl ?: "",
                    onDownload = {},
                    onOpenManager = {},
                    onOpenLibrary = {}
                )
            }
        }
    }
    override fun onResume() {
        super.onResume()
        // Clipboard: sudhu foreground e ekbar check - background e continuous read NAI
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip?.getItemAt(0)?.text?.toString()
        if (clip?.startsWith("http") == true) {
            // ViewModel e paste suggestion pathabe - ekhane silent read kore download kora hobe na
        }
    }
}
