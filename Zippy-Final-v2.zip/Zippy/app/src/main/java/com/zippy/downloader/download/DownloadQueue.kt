package com.zippy.downloader.download

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class DownloadTask(
    val id: String, val url: String, val title: String, val formatId: String, val ext: String,
    val status: String = "QUEUED", val progress: Float = 0f,
    val downloadedBytes: Long = 0, val totalBytes: Long = 0, val speedBps: Long = 0
)

class DownloadQueue(private val ctx: Context) {
    private val _tasks = MutableStateFlow<List<DownloadTask>>(emptyList())
    val tasks: StateFlow<List<DownloadTask>> = _tasks

    fun enqueue(task: DownloadTask) {
        _tasks.value = _tasks.value + task
        val data = workDataOf("url" to task.url, "formatId" to task.formatId, "title" to task.title, "taskId" to task.id)
        val req = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(data)
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(task.id, ExistingWorkPolicy.KEEP, req)
    }
    fun pause(id: String) {
        WorkManager.getInstance(ctx).cancelUniqueWork(id)
        _tasks.value = _tasks.value.map { if (it.id == id) it.copy(status = "PAUSED") else it }
    }
    fun retry(id: String) {
        val t = _tasks.value.find { it.id == id } ?: return
        enqueue(t.copy(status = "QUEUED", progress = 0f))
    }
    fun cancel(id: String) {
        WorkManager.getInstance(ctx).cancelUniqueWork(id)
        _tasks.value = _tasks.value.filterNot { it.id == id }
    }
}
