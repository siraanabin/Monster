package com.zippy.downloader

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ZippyApp : Application()
