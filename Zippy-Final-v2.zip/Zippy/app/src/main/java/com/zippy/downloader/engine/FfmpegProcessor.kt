package com.zippy.downloader.engine

import com.arthenica.ffmpegkitnext.FFmpegKit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// FFmpegKitNext = FFmpegKit er official continuation (FFmpegKit retired Jan 2025, archived Jul 2026)
// Merge: video-only + audio-only -> MP4/MKV/WebM, Convert: -> MP3/M4A/AAC
object FfmpegProcessor {
    suspend fun merge(video: File, audio: File, output: File): Result<File> = withContext(Dispatchers.IO) {
        val session = FFmpegKit.execute("-y -i ${video.absolutePath} -i ${audio.absolutePath} -c copy ${output.absolutePath}")
        if (session.returnCode.isValueSuccess) Result.success(output)
        else Result.failure(Exception("Merge failed"))
    }
    suspend fun convertToAudio(input: File, output: File, format: String): Result<File> = withContext(Dispatchers.IO) {
        val codec = when (format.lowercase()) { "mp3" -> "libmp3lame"; "m4a", "aac" -> "aac"; else -> "libmp3lame" }
        val session = FFmpegKit.execute("-y -i ${input.absolutePath} -vn -c:a $codec -q:a 2 ${output.absolutePath}")
        if (session.returnCode.isValueSuccess) Result.success(output)
        else Result.failure(Exception("Convert failed"))
    }
}
